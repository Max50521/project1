# GeniusAPI
# Cyrilourd & Popszer
# See LICENSE for details

"""A library that provides a Python interface to the Genius API"""

__author__ = 'Cyrilourd and Popszer'
__description__ = 'A Python wrapper around the Genius API'

from genius.api import Genius